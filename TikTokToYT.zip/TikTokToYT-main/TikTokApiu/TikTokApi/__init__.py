"""
.. include:: ../README.md
"""
__docformat__ = "restructuredtext"

from TikTokApiu.TikTokApi.tiktok import TikTokApi
